CHASE ANALYTICS BROADCASTING BOOTH
=================================

INSTALL ON A DIFFERENT WINDOWS COMPUTER
1. Extract every file from the ZIP. Do not run the installer from inside the ZIP preview.
2. Double-click INSTALL-BOOTH.cmd.
3. Wait for the window to say INSTALLATION COMPLETE.
4. Open a new terminal and type booth, or use the new desktop shortcuts.

The installer detects that computer's username, Documents folder, Desktop folder, Python
installation and PowerShell profiles. It does not reuse paths from the computer that built
this package.

You do not need to type setup commands.

IF YOU PREFER THE TERMINAL
These commands work from any folder:
- booth
- booth-list
- booth-four

ON YOUR DESKTOP
1. Double-click "Broadcasting Booth" to choose games from a numbered menu.
2. Or double-click "Tomorrow's Four NFL Games" to generate all four prepared matchups.

YOUR OUTPUTS
Open this folder after the run finishes:
NFLBooth\dist\broadcast-booth

Each selected matchup receives six PNG graphics. The same output folder also contains:
- broadcast-booth-producer-runbook.md
- broadcast-booth-selection.json

IF SOMETHING FAILS
The command window stays open and explains the problem. The detailed diagnostic file is:
NFLBooth\broadcast-booth-launch.log
