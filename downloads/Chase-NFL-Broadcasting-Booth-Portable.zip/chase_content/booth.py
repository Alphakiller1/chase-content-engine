from __future__ import annotations

import datetime as dt
from pathlib import Path
from typing import Callable
from zoneinfo import ZoneInfo

from chase_content.broadcast_booth import render_broadcast_booth
from chase_content.util import write_json


def game_key(game: dict) -> str:
    return f"{game.get('away', '')}@{game.get('home', '')}".upper()


def _kickoff_label(raw: object) -> str:
    try:
        stamp = dt.datetime.fromisoformat(str(raw).replace("Z", "+00:00"))
        local = stamp.astimezone(ZoneInfo("America/New_York"))
    except (TypeError, ValueError):
        return "Time unavailable"
    return local.strftime("%a %b %d - %I:%M %p ET").replace("- 0", "- ")


def available_games(
    bundle: dict,
    *,
    week: int | None = None,
    include_final: bool = False,
) -> list[dict]:
    nfl = (bundle.get("sports") or {}).get("nfl") or {}
    target_week = week if week is not None else nfl.get("current_week")
    games = []
    for game in nfl.get("games") or []:
        if target_week is not None and game.get("week") != target_week:
            continue
        if not include_final and str(game.get("game_state") or "").casefold() == "final":
            continue
        games.append(game)
    return games


def print_game_menu(games: list[dict], output: Callable[[str], None] = print) -> None:
    output("\nCHASE ANALYTICS BROADCASTING BOOTH")
    output("Select the games you are preparing for:\n")
    for index, game in enumerate(games, start=1):
        output(
            f"  {index:>2}. {game_key(game):<9} "
            f"{game.get('away_name') or game.get('away')} at "
            f"{game.get('home_name') or game.get('home')}  |  "
            f"{_kickoff_label(game.get('kickoff_utc'))}  |  "
            f"{game.get('broadcast') or 'Network unavailable'}"
        )
    output("\nEnter menu numbers, game keys, or all. Example: 2,4 or CIN@HOU,JAX@DEN")


def parse_selection(selection: str, games: list[dict]) -> list[dict]:
    raw = str(selection or "").strip()
    if not raw:
        raise ValueError("no games were selected")
    if raw.casefold() == "all":
        return list(games)
    by_key = {game_key(game): game for game in games}
    selected: list[dict] = []
    unknown: list[str] = []
    for token in (item.strip() for item in raw.split(",")):
        if not token:
            continue
        game = None
        if token.isdigit():
            index = int(token) - 1
            if 0 <= index < len(games):
                game = games[index]
        else:
            game = by_key.get(token.upper())
        if game is None:
            unknown.append(token)
        elif game not in selected:
            selected.append(game)
    if unknown:
        raise ValueError(f"unknown game selections: {', '.join(unknown)}")
    if not selected:
        raise ValueError("no valid games were selected")
    return selected


def choose_games(
    games: list[dict],
    selection: str | None,
    *,
    input_fn: Callable[[str], str] = input,
    output: Callable[[str], None] = print,
) -> list[dict]:
    print_game_menu(games, output)
    raw = selection if selection is not None else input_fn("\nGame selection: ")
    return parse_selection(raw, games)


def _notes_for(notes: dict, key: str) -> dict:
    return ((notes.get("games") or {}).get(key) or {})


def export_booth_documents(
    bundle: dict,
    selected: list[dict],
    out_dir: Path,
    *,
    broadcast_notes: dict,
    rendered_paths: dict[str, list[Path]],
) -> tuple[Path, Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = out_dir / "broadcast-booth-selection.json"
    markdown_path = out_dir / "broadcast-booth-producer-runbook.md"
    rows = []
    for game in selected:
        key = game_key(game)
        rows.append({
            "game": key,
            "game_id": game.get("id"),
            "away_name": game.get("away_name"),
            "home_name": game.get("home_name"),
            "kickoff_utc": game.get("kickoff_utc"),
            "broadcast": game.get("broadcast"),
            "venue": game.get("venue"),
            "artifacts": [path.relative_to(out_dir).as_posix() for path in rendered_paths.get(key, [])],
        })
    write_json(
        manifest_path,
        {
            "schema": "chase-broadcast-booth-selection/1",
            "generated_at_utc": dt.datetime.now(dt.timezone.utc).isoformat().replace("+00:00", "Z"),
            "source_generated_at_utc": bundle["sports"]["nfl"].get("generated_at_utc"),
            "games": rows,
        },
    )
    lines = [
        "# Broadcasting Booth Producer Runbook",
        "",
        "This runbook records the games selected for video preparation and the six-artifact package produced for each matchup.",
        "",
        "## Selected Games",
        "",
    ]
    for game in selected:
        key = game_key(game)
        notes = _notes_for(broadcast_notes, key)
        lines.extend([
            f"### {game.get('away_name') or game.get('away')} at {game.get('home_name') or game.get('home')}",
            "",
            f"- Game key: `{key}`",
            f"- Kickoff: {_kickoff_label(game.get('kickoff_utc'))}",
            f"- Network: {game.get('broadcast') or 'Unavailable'}",
            f"- Venue: {game.get('venue') or 'Unavailable'}",
            f"- Records: {game.get('away_record') or '—'} / {game.get('home_record') or '—'}",
            f"- Week 1: {notes.get('week_1_summary') or 'Unavailable'}",
            f"- Broadcast angle: {notes.get('storyline') or 'Use the published matchup evidence.'}",
            "",
            "Artifacts:",
            "",
        ])
        for path in rendered_paths.get(key, []):
            lines.append(f"- `{path.relative_to(out_dir).as_posix()}`")
        lines.extend([
            "",
            "Pregame checks:",
            "",
            "- [ ] Confirm active starting quarterback",
            "- [ ] Confirm final inactive list",
            "- [ ] Confirm venue roof and weather state",
            "- [ ] Confirm graphics use the latest public contract",
            "",
        ])
    lines.extend([
        "## Terminal Commands",
        "",
        "```powershell",
        "python -m chase_content booth --site-base https://chase-analytics.com --broadcast-notes broadcast_booth/2026-week-02.json --out dist/booth",
        "python -m chase_content booth --site-base https://chase-analytics.com --games CIN@HOU,JAX@DEN --broadcast-notes broadcast_booth/2026-week-02.json --out dist/booth",
        "```",
        "",
        "The first command opens the interactive game picker. The second command is repeatable and noninteractive.",
    ])
    markdown_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return markdown_path, manifest_path


def run_booth(
    bundle: dict,
    out_dir: Path,
    *,
    broadcast_notes: dict,
    selection: str | None = None,
    week: int | None = None,
    include_final: bool = False,
    list_only: bool = False,
    input_fn: Callable[[str], str] = input,
    output: Callable[[str], None] = print,
) -> list[Path]:
    games = available_games(bundle, week=week, include_final=include_final)
    if not games:
        raise ValueError("no NFL games are available for the selected week")
    if list_only:
        print_game_menu(games, output)
        return []
    selected = choose_games(games, selection, input_fn=input_fn, output=output)
    rendered: dict[str, list[Path]] = {}
    all_paths: list[Path] = []
    for game in selected:
        key = game_key(game)
        game_dir = out_dir / key.replace("@", "-")
        paths = render_broadcast_booth(
            bundle,
            game_dir,
            key,
            broadcast_notes=broadcast_notes,
        )
        rendered[key] = paths
        all_paths.extend(paths)
        output(f"Prepared {key}: {len(paths)} graphics")
    markdown, manifest = export_booth_documents(
        bundle,
        selected,
        out_dir,
        broadcast_notes=broadcast_notes,
        rendered_paths=rendered,
    )
    all_paths.extend([markdown, manifest])
    output(f"Exported producer runbook: {markdown}")
    output(f"Exported selection manifest: {manifest}")
    return all_paths
