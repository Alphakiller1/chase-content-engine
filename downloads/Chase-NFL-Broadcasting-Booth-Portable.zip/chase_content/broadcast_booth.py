from __future__ import annotations

import math
from io import BytesIO
from pathlib import Path
from urllib.request import Request, urlopen

from PIL import Image, ImageDraw, ImageFilter

from chase_content.render import (
    BG,
    BORDER,
    FONTS,
    GOLD,
    GREEN,
    MUTED,
    PANEL,
    PANEL_ALT,
    PURPLE,
    RED,
    TEXT,
    _font,
    _metallic_text,
)
from chase_content.site import find_game
from chase_content.util import number, truncate


TEAM_ACCENTS = {
    "CIN": "#FB4F14",
    "HOU": "#D71920",
    "JAX": "#00A5B5",
    "DEN": "#FB4F14",
    "WAS": "#FFB612",
    "DAL": "#7FA8C9",
    "PIT": "#FFB612",
    "NE": "#C60C30",
}

BIG_TEAM = _font(70, display=True, bold=True)
QB_NAME = _font(35, display=True, bold=True)
HERO_METRIC = _font(34, display=True, bold=True)
MICRO = _font(12)
MICRO_BOLD = _font(12, bold=True)
FORMATION_LABEL = _font(14, display=True, bold=True)
_PORTRAITS: dict[str, Image.Image | None] = {}


def _accent(team: object) -> str:
    return TEAM_ACCENTS.get(str(team or "").upper(), PURPLE)


def _rank_tone(rank: object, total: object) -> str:
    try:
        percentile = 1 - ((int(rank) - 1) / max(1, int(total) - 1))
    except (TypeError, ValueError):
        return MUTED
    if percentile >= 2 / 3:
        return GREEN
    if percentile >= 1 / 3:
        return GOLD
    return RED


def _fmt_rate(value: object, *, signed: bool = False) -> str:
    n = number(value)
    if n is None:
        return "—"
    return f"{n:+.3f}" if signed else f"{n * 100:.1f}%"


def _fmt_form_value(metric: dict) -> str:
    value = number(metric.get("value"))
    if value is None:
        return "—"
    label = str(metric.get("label") or "")
    return f"{value:+.3f}" if "EPA" in label else f"{value * 100:.1f}%"


def _wrap(text: object, font: object, max_width: int, max_lines: int = 2) -> str:
    words = str(text or "").split()
    lines: list[str] = []
    current = ""
    for word in words:
        candidate = f"{current} {word}".strip()
        if font.getlength(candidate) <= max_width:
            current = candidate
            continue
        if current:
            lines.append(current)
        current = word
        if len(lines) == max_lines - 1:
            break
    if current and len(lines) < max_lines:
        remaining = " ".join(words[sum(len(line.split()) for line in lines):])
        current = remaining
        while current and font.getlength(current + "…") > max_width:
            current = current[:-1].rstrip()
        lines.append(current + ("…" if current != remaining else ""))
    return "\n".join(lines[:max_lines])


def _save(image: Image.Image, out_dir: Path, name: str) -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / name
    image.save(path, quality=96)
    return path


def _base(game: dict, page_title: str, page_no: int, subtitle: str) -> tuple[Image.Image, ImageDraw.ImageDraw]:
    image = Image.new("RGB", (1080, 1350), BG)
    glow = Image.new("RGBA", image.size, (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.ellipse((-250, -280, 600, 520), fill=(*ImageColor.getrgb(_accent(game.get("away"))), 30))
    gd.ellipse((520, -300, 1330, 500), fill=(*ImageColor.getrgb(_accent(game.get("home"))), 27))
    glow = glow.filter(ImageFilter.GaussianBlur(85))
    image = Image.alpha_composite(image.convert("RGBA"), glow).convert("RGB")
    draw = ImageDraw.Draw(image)
    for x in range(60, 1021, 80):
        draw.line((x, 250, x, 1265), fill="#0E111A", width=1)
    for y in range(250, 1266, 80):
        draw.line((60, y, 1020, y), fill="#0E111A", width=1)
    draw.text((60, 40), "CHASE ANALYTICS  /  BROADCASTING BOOTH", font=FONTS["eyebrow"], fill=PURPLE)
    draw.text((1020, 44), f"{page_no:02d} / 06", font=FONTS["small_bold"], fill=MUTED, anchor="ra")
    _metallic_text(image, (60, 78), page_title, FONTS["title"])
    draw.text((60, 144), subtitle, font=FONTS["subtitle"], fill=MUTED)
    draw.line((60, 210, 1020, 210), fill=BORDER, width=2)
    away, home = str(game.get("away") or "—"), str(game.get("home") or "—")
    draw.rounded_rectangle((60, 170, 215, 202), radius=10, fill=_accent(away))
    draw.text((137, 186), away, font=FONTS["small_bold"], fill="#090A0F", anchor="mm")
    draw.text((235, 186), "AT", font=FONTS["tiny"], fill=MUTED, anchor="mm")
    draw.rounded_rectangle((255, 170, 410, 202), radius=10, fill=_accent(home))
    draw.text((332, 186), home, font=FONTS["small_bold"], fill="#090A0F", anchor="mm")
    return image, draw


def _footer(draw: ImageDraw.ImageDraw, bundle: dict, note: str = "Public contract · no fabricated values") -> None:
    draw.line((60, 1292, 1020, 1292), fill=BORDER, width=2)
    updated = str(bundle["sports"]["nfl"].get("generated_at_utc") or "unknown").replace("T", " ")
    draw.text((60, 1316), f"{note} · Updated {updated}", font=FONTS["tiny"], fill=MUTED)
    draw.text((1020, 1316), "chase-analytics.com", font=FONTS["tiny"], fill=PURPLE, anchor="ra")


def _qb_player(game: dict, side: str) -> dict:
    for player in (((game.get(f"{side}_lineups") or {}).get("offense") or {}).get("players") or []):
        if player.get("position") == "QB":
            return player
    return {"name": game.get(f"{side}_starter") or "QB unavailable", "position": "QB"}


def _portrait(url: object, size: int = 132) -> Image.Image | None:
    key = str(url or "")
    if not key:
        return None
    if key not in _PORTRAITS:
        try:
            request = Request(key, headers={"User-Agent": "chase-content-engine/0.3"})
            with urlopen(request, timeout=12) as response:  # noqa: S310 - published image URL
                source = Image.open(BytesIO(response.read())).convert("RGBA")
            source.thumbnail((size, size), Image.Resampling.LANCZOS)
            canvas = Image.new("RGBA", (size, size), (0, 0, 0, 0))
            canvas.alpha_composite(source, ((size - source.width) // 2, size - source.height))
            mask = Image.new("L", (size, size), 0)
            ImageDraw.Draw(mask).ellipse((2, 2, size - 2, size - 2), fill=255)
            canvas.putalpha(mask)
            _PORTRAITS[key] = canvas
        except Exception:
            _PORTRAITS[key] = None
    return _PORTRAITS[key]


def _notes_for(notes: dict, game: dict) -> dict:
    key = f"{game.get('away')}@{game.get('home')}"
    return ((notes.get("games") or {}).get(key) or {})


def _panel(draw: ImageDraw.ImageDraw, box: tuple[int, int, int, int], *, accent: str | None = None) -> None:
    draw.rounded_rectangle(box, radius=22, fill=PANEL, outline=BORDER, width=2)
    if accent:
        draw.rounded_rectangle((box[0], box[1], box[0] + 8, box[3]), radius=4, fill=accent)


def _context_chip(draw: ImageDraw.ImageDraw, x: int, y: int, w: int, label: str, value: str, tone: str = TEXT) -> None:
    draw.rounded_rectangle((x, y, x + w, y + 78), radius=16, fill=PANEL_ALT, outline=BORDER, width=1)
    draw.text((x + 16, y + 13), label.upper(), font=MICRO_BOLD, fill=MUTED)
    draw.text((x + 16, y + 38), truncate(value, max(12, w // 11)), font=FONTS["small_bold"], fill=tone)


def _team_form_metric(game: dict, side: str, key: str) -> dict:
    return ((((game.get(f"{side}_form") or {}).get("rates") or {}).get(key)) or {})


def _team_edge_block(draw: ImageDraw.ImageDraw, game: dict, side: str, box: tuple[int, int, int, int]) -> None:
    team = str(game.get(side) or "—")
    name = str(game.get(f"{side}_name") or team)
    _panel(draw, box, accent=_accent(team))
    x1, y1, x2, _ = box
    draw.text((x1 + 26, y1 + 22), team, font=BIG_TEAM, fill=_accent(team))
    draw.text((x1 + 150, y1 + 35), truncate(name, 22), font=FONTS["panel_title"], fill=TEXT)
    draw.text((x2 - 24, y1 + 36), str(game.get(f"{side}_record") or "—"), font=FONTS["rank"], fill=TEXT, anchor="ra")
    y = y1 + 118
    metrics = (
        ("off_epa", "OFF EPA/PLAY"),
        ("off_explosive", "EXPLOSIVE RATE"),
        ("off_sack", "SACK RATE TAKEN"),
        ("def_epa", "DEF EPA ALLOWED"),
        ("def_sack", "PRESSURE FINISH"),
        ("def_turnover", "TAKEAWAY RATE"),
    )
    for key, label in metrics:
        metric = _team_form_metric(game, side, key)
        tone = _rank_tone(metric.get("rank"), metric.get("of"))
        draw.text((x1 + 26, y), label, font=MICRO_BOLD, fill=MUTED)
        draw.text((x2 - 120, y), _fmt_form_value(metric), font=FONTS["small_bold"], fill=TEXT, anchor="ra")
        draw.text((x2 - 24, y), f"#{metric.get('rank', '—')}", font=FONTS["small_bold"], fill=tone, anchor="ra")
        y += 48


def _matchup_desk(bundle: dict, game: dict, notes: dict, out_dir: Path) -> Path:
    image, draw = _base(game, "MATCHUP DESK", 1, "The full producer board before the opening tease")
    n = _notes_for(notes, game)
    _team_edge_block(draw, game, "away", (60, 250, 520, 670))
    _team_edge_block(draw, game, "home", (560, 250, 1020, 670))
    draw.rounded_rectangle((60, 700, 1020, 820), radius=20, fill="#151221", outline=PURPLE, width=2)
    draw.text((82, 720), "BROADCAST ANGLE", font=FONTS["small_bold"], fill=PURPLE)
    draw.multiline_text(
        (82, 752),
        _wrap(n.get("storyline") or "Scheme and availability decide the matchup.", FONTS["body"], 910, 2),
        font=FONTS["body"],
        fill=TEXT,
        spacing=5,
    )
    from chase_content.render_site import _date_time

    _context_chip(draw, 60, 840, 300, "Kickoff / Network", f"{_date_time(game.get('kickoff_utc'))} · {game.get('broadcast') or '—'}", GOLD)
    _context_chip(draw, 390, 840, 300, "Venue", f"{game.get('venue') or '—'} · {game.get('roof') or '—'}")
    _context_chip(draw, 720, 840, 300, "Week 1", str(n.get("week_1_summary") or "Result unavailable"))
    _context_chip(draw, 60, 940, 465, f"{game.get('away')} availability", str(game.get("away_availability") or "No designation summary"), GOLD)
    _context_chip(draw, 555, 940, 465, f"{game.get('home')} availability", str(game.get("home_availability") or "No designation summary"), GOLD)
    _context_chip(draw, 60, 1040, 465, f"{game.get('away')} rest / travel", f"{game.get('away_rest_days', '—')} days · {game.get('away_travel') or '—'}")
    _context_chip(draw, 555, 1040, 465, f"{game.get('home')} rest / travel", f"{game.get('home_rest_days', '—')} days · {game.get('home_travel') or '—'}")
    draw.text((60, 1145), "PRODUCER CHECK", font=FONTS["small_bold"], fill=PURPLE)
    draw.text((60, 1180), "Confirm inactive list, starting quarterback, and roof/conditions before air.", font=FONTS["body"], fill=TEXT)
    _footer(draw, bundle)
    return _save(image, out_dir, f"nfl-{game.get('away')}-{game.get('home')}-booth-01-matchup-desk.png")


def _qb_card(image: Image.Image, draw: ImageDraw.ImageDraw, game: dict, side: str, notes: dict, box: tuple[int, int, int, int]) -> None:
    team = str(game.get(side) or "—")
    opp_side = "home" if side == "away" else "away"
    player = _qb_player(game, side)
    qb_notes = (((notes.get("qbs") or {}).get(team)) or {})
    x1, y1, x2, _ = box
    _panel(draw, box, accent=_accent(team))
    shot = _portrait(player.get("headshot_url"))
    if shot:
        image.paste(shot, (x1 + 24, y1 + 24), shot)
        draw.ellipse((x1 + 24, y1 + 24, x1 + 156, y1 + 156), outline=_accent(team), width=4)
    else:
        draw.ellipse((x1 + 24, y1 + 24, x1 + 156, y1 + 156), fill=PANEL_ALT, outline=_accent(team), width=4)
        draw.text((x1 + 90, y1 + 90), team, font=FONTS["panel_title"], fill=_accent(team), anchor="mm")
    draw.text((x1 + 178, y1 + 28), team, font=FONTS["small_bold"], fill=_accent(team))
    draw.text((x1 + 178, y1 + 58), truncate(player.get("name") or "QB unavailable", 20), font=QB_NAME, fill=TEXT)
    draw.text((x1 + 178, y1 + 104), str(qb_notes.get("result") or "Week 1 line unavailable"), font=FONTS["small"], fill=MUTED)
    draw.text((x1 + 178, y1 + 132), str(qb_notes.get("source_label") or "Sourced stat line"), font=MICRO, fill=MUTED)
    stats = (
        ("COMP / ATT", qb_notes.get("comp_att")),
        ("PASS YDS", qb_notes.get("yards")),
        ("TD – INT", qb_notes.get("td_int")),
        ("COMP %", qb_notes.get("completion_pct")),
        ("Y / ATT", qb_notes.get("yards_per_attempt")),
        ("RATING", qb_notes.get("rating")),
    )
    sy = y1 + 190
    for idx, (label, value) in enumerate(stats):
        col, row = idx % 3, idx // 3
        sx, yy = x1 + 24 + col * 142, sy + row * 90
        draw.text((sx, yy), label, font=MICRO_BOLD, fill=MUTED)
        draw.text((sx, yy + 25), str(value if value not in (None, "") else "—"), font=HERO_METRIC, fill=TEXT)
    offense = ((game.get(f"{side}_scheme") or {}).get("offense") or {})
    response = offense.get("response") or {}
    defense = ((game.get(f"{opp_side}_scheme") or {}).get("defense") or {})
    coverage = defense.get("coverage") or {}
    pressure = defense.get("pressure") or {}
    draw.line((x1 + 24, y1 + 382, x2 - 24, y1 + 382), fill=BORDER, width=2)
    draw.text((x1 + 24, y1 + 405), f"MATCHUP VS {game.get(opp_side)} DEFENSE", font=FONTS["small_bold"], fill=PURPLE)
    rows = (
        ("MAN", coverage.get("man_rate"), response.get("pass_epa_man")),
        ("ZONE", coverage.get("zone_rate"), response.get("pass_epa_zone")),
        ("BLITZ", pressure.get("blitz_rate"), response.get("pass_epa_blitz")),
        ("PRESSURE", pressure.get("pressure_rate"), response.get("pass_epa_pressure")),
    )
    yy = y1 + 454
    draw.text((x1 + 24, yy - 23), "LOOK", font=MICRO_BOLD, fill=MUTED)
    draw.text((x2 - 180, yy - 23), "DEF FREQ", font=MICRO_BOLD, fill=MUTED, anchor="ra")
    draw.text((x2 - 24, yy - 23), "OFF EPA/DB", font=MICRO_BOLD, fill=MUTED, anchor="ra")
    for label, freq, epa in rows:
        draw.text((x1 + 24, yy), label, font=FONTS["small_bold"], fill=TEXT)
        draw.text((x2 - 180, yy), _fmt_rate(freq), font=FONTS["small_bold"], fill=TEXT, anchor="ra")
        epa_n = number(epa)
        tone = GREEN if epa_n is not None and epa_n > 0 else (RED if epa_n is not None and epa_n < 0 else MUTED)
        draw.text((x2 - 24, yy), _fmt_rate(epa, signed=True), font=FONTS["small_bold"], fill=tone, anchor="ra")
        yy += 48
    draw.rounded_rectangle((x1 + 24, y1 + 672, x2 - 24, y1 + 776), radius=14, fill=PANEL_ALT)
    draw.text((x1 + 40, y1 + 687), "ON-AIR READ", font=MICRO_BOLD, fill=_accent(team))
    draw.multiline_text(
        (x1 + 40, y1 + 714),
        _wrap(qb_notes.get("takeaway") or "Use the scheme response, not reputation, to frame the matchup.", FONTS["small"], x2 - x1 - 80, 2),
        font=FONTS["small"],
        fill=TEXT,
        spacing=4,
    )


def _qb_duel(bundle: dict, game: dict, notes: dict, out_dir: Path) -> Path:
    image, draw = _base(game, "QB DUEL", 2, "Week 1 production paired with the defensive menu each passer faces")
    n = _notes_for(notes, game)
    _qb_card(image, draw, game, "away", n, (60, 250, 520, 1050))
    _qb_card(image, draw, game, "home", n, (560, 250, 1020, 1050))
    draw.rounded_rectangle((60, 1080, 1020, 1240), radius=20, fill="#151221", outline=PURPLE, width=2)
    draw.text((82, 1102), "COMPARISON NOTE", font=FONTS["small_bold"], fill=PURPLE)
    draw.text((82, 1138), "Week 1 passing is a one-game sample. Scheme EPA uses the published 2025–26 evidence window.", font=FONTS["body"], fill=TEXT)
    draw.text((82, 1182), "Green/red EPA values describe offense response to the look—not a game prediction.", font=FONTS["small"], fill=MUTED)
    _footer(draw, bundle, "QB box scores + published scheme contract")
    return _save(image, out_dir, f"nfl-{game.get('away')}-{game.get('home')}-booth-02-qb-duel.png")


def _arrow(draw: ImageDraw.ImageDraw, points: list[tuple[int, int]], fill: str, width: int = 3) -> None:
    draw.line(points, fill=fill, width=width, joint="curve")
    if len(points) < 2:
        return
    x1, y1 = points[-2]
    x2, y2 = points[-1]
    ang = math.atan2(y2 - y1, x2 - x1)
    length = 10
    for delta in (2.55, -2.55):
        draw.line((x2, y2, x2 + length * math.cos(ang + delta), y2 + length * math.sin(ang + delta)), fill=fill, width=width)


def _formation_name(personnel: dict) -> tuple[str, str, float | None]:
    choices = {
        "11 PERSONNEL": number(personnel.get("personnel_11_rate")),
        "12 PERSONNEL": number(personnel.get("personnel_12_rate")),
        "21 PERSONNEL": number(personnel.get("personnel_21_rate")),
    }
    valid = [(name, rate) for name, rate in choices.items() if rate is not None]
    name, rate = max(valid, key=lambda row: row[1]) if valid else ("BASE OFFENSE", None)
    shotgun = number(personnel.get("formation_shotgun_rate"))
    under = number(personnel.get("formation_under_center_rate"))
    alignment = "SHOTGUN" if shotgun is not None and (under is None or shotgun >= under) else "UNDER CENTER"
    return name, alignment, rate


def _dot(draw: ImageDraw.ImageDraw, x: int, y: int, label: str, accent: str, *, square: bool = False) -> None:
    box = (x - 17, y - 17, x + 17, y + 17)
    if square:
        draw.rounded_rectangle(box, radius=6, fill="#0B0D13", outline=accent, width=2)
    else:
        draw.ellipse(box, fill="#0B0D13", outline=accent, width=2)
    draw.text((x, y), label, font=FORMATION_LABEL, fill=TEXT, anchor="mm")


def _draw_formation(draw: ImageDraw.ImageDraw, box: tuple[int, int, int, int], personnel_name: str, alignment: str, accent: str) -> None:
    x1, y1, x2, y2 = box
    draw.rounded_rectangle(box, radius=18, fill="#0B1512", outline="#28523F", width=2)
    for yy in range(y1 + 45, y2, 54):
        draw.line((x1 + 16, yy, x2 - 16, yy), fill="#244637", width=1)
    draw.line((x1 + 18, y1 + 188, x2 - 18, y1 + 188), fill=GOLD, width=3)
    center = (x1 + x2) // 2
    for idx, label in enumerate(("LT", "LG", "C", "RG", "RT")):
        _dot(draw, center - 92 + idx * 46, y1 + 205, label, accent, square=True)
    gun = alignment == "SHOTGUN"
    _dot(draw, center, y1 + (260 if gun else 235), "QB", accent)
    _dot(draw, center + (65 if gun else 0), y1 + (292 if gun else 292), "RB", accent)
    _dot(draw, x1 + 42, y1 + 142, "X", accent)
    _dot(draw, x2 - 42, y1 + 142, "Z", accent)
    if personnel_name.startswith("11"):
        _dot(draw, x1 + 116, y1 + 166, "H", accent)
        _dot(draw, x2 - 116, y1 + 184, "Y", accent)
    elif personnel_name.startswith("12"):
        _dot(draw, center - 138, y1 + 184, "Y", accent)
        _dot(draw, center + 138, y1 + 184, "U", accent)
    else:
        _dot(draw, center + 130, y1 + 184, "Y", accent)
        _dot(draw, center - 52, y1 + 292, "F", accent)
    _arrow(draw, [(x1 + 42, y1 + 125), (x1 + 42, y1 + 62), (x1 + 90, y1 + 38)], accent)
    _arrow(draw, [(x2 - 42, y1 + 125), (x2 - 42, y1 + 74)], accent)
    draw.text((x1 + 16, y2 - 26), f"{personnel_name} · {alignment}", font=MICRO_BOLD, fill=TEXT)
    draw.text((x2 - 16, y2 - 26), "STRUCTURE, NOT A PLAY CALL", font=MICRO, fill=MUTED, anchor="ra")


def _usage_rows(draw: ImageDraw.ImageDraw, personnel: dict, x: int, y: int, w: int) -> None:
    rows = (
        ("11P", personnel.get("personnel_11_rate")),
        ("12P", personnel.get("personnel_12_rate")),
        ("21P", personnel.get("personnel_21_rate")),
        ("SHOTGUN", personnel.get("formation_shotgun_rate")),
        ("MOTION", personnel.get("motion_rate")),
        ("PLAY ACTION", personnel.get("play_action_rate")),
        ("RPO", personnel.get("rpo_rate")),
        ("SCREEN", personnel.get("screen_rate")),
    )
    for idx, (label, value) in enumerate(rows):
        col, row = idx % 2, idx // 2
        xx, yy = x + col * (w // 2), y + row * 48
        draw.text((xx, yy), label, font=MICRO_BOLD, fill=MUTED)
        draw.text((xx + w // 2 - 28, yy), _fmt_rate(value), font=FONTS["small_bold"], fill=TEXT, anchor="ra")


def _formation_half(draw: ImageDraw.ImageDraw, game: dict, side: str, box: tuple[int, int, int, int]) -> None:
    team = str(game.get(side) or "—")
    x1, y1, x2, _ = box
    _panel(draw, box, accent=_accent(team))
    personnel = ((((game.get(f"{side}_scheme") or {}).get("offense") or {}).get("personnel")) or {})
    name, alignment, rate = _formation_name(personnel)
    draw.text((x1 + 24, y1 + 20), f"{team} OFFENSE", font=FONTS["panel_title"], fill=_accent(team))
    draw.text((x2 - 24, y1 + 28), f"{_fmt_rate(rate)} PRIMARY", font=FONTS["small_bold"], fill=TEXT, anchor="ra")
    _draw_formation(draw, (x1 + 24, y1 + 72, x2 - 24, y1 + 455), name, alignment, _accent(team))
    draw.text((x1 + 24, y1 + 486), "FORMATION + TENDENCY MENU", font=FONTS["small_bold"], fill=PURPLE)
    _usage_rows(draw, personnel, x1 + 24, y1 + 526, x2 - x1 - 48)


def _formation_lab(bundle: dict, game: dict, out_dir: Path) -> Path:
    image, draw = _base(game, "FORMATION LAB", 3, "Personnel, alignment and constraint usage translated into a formation board")
    _formation_half(draw, game, "away", (60, 250, 520, 1030))
    _formation_half(draw, game, "home", (560, 250, 1020, 1030))
    draw.rounded_rectangle((60, 1060, 1020, 1240), radius=20, fill=PANEL, outline=BORDER, width=2)
    draw.text((82, 1084), "HOW TO USE THIS BOARD", font=FONTS["small_bold"], fill=PURPLE)
    draw.multiline_text(
        (82, 1118),
        _wrap("The diagram shows the offense’s most-used personnel family and alignment—not a predicted first play.", FONTS["body"], 900, 2),
        font=FONTS["body"],
        fill=TEXT,
        spacing=5,
    )
    draw.text((82, 1190), "Motion, play-action, RPO and screen rates reveal which constraints the defense must honor.", font=FONTS["small"], fill=MUTED)
    _footer(draw, bundle, "Published formation and personnel participation")
    return _save(image, out_dir, f"nfl-{game.get('away')}-{game.get('home')}-booth-03-formation-lab.png")


def _coverage_panel(draw: ImageDraw.ImageDraw, game: dict, off_side: str, box: tuple[int, int, int, int]) -> None:
    def_side = "home" if off_side == "away" else "away"
    x1, y1, x2, y2 = box
    _panel(draw, box, accent=_accent(game.get(off_side)))
    offense = ((game.get(f"{off_side}_scheme") or {}).get("offense") or {})
    defense_root = game.get(f"{def_side}_scheme") or {}
    defense = defense_root.get("defense") or {}
    coverage = defense.get("coverage") or {}
    response = offense.get("response") or {}
    ranks = ((((defense_root.get("league_frequency_ranks") or {}).get("defense") or {}).get("coverage")) or {})
    draw.text((x1 + 24, y1 + 18), f"{game.get(off_side)} OFFENSE  vs  {game.get(def_side)} DEFENSE", font=FONTS["panel_title"], fill=TEXT)
    draw.text((x1 + 24, y1 + 58), "DEFENSIVE MENU", font=MICRO_BOLD, fill=MUTED)
    draw.text((x1 + 260, y1 + 58), "FREQ", font=MICRO_BOLD, fill=MUTED, anchor="ra")
    draw.text((x1 + 332, y1 + 58), "RK", font=MICRO_BOLD, fill=MUTED, anchor="ra")
    draw.text((x1 + 430, y1 + 58), "OFF EPA", font=MICRO_BOLD, fill=MUTED, anchor="ra")
    cov_rows = (
        ("MAN", "man_rate", "pass_epa_man"),
        ("ZONE", "zone_rate", "pass_epa_zone"),
        ("COVER 0", "cover_0_rate", "pass_epa_cover_0"),
        ("COVER 1", "cover_1_rate", "pass_epa_cover_1"),
        ("COVER 2", "cover_2_rate", "pass_epa_cover_2"),
        ("COVER 3", "cover_3_rate", "pass_epa_cover_3"),
        ("COVER 4", "cover_4_rate", "pass_epa_cover_4"),
        ("COVER 6", "cover_6_rate", "pass_epa_cover_6"),
    )
    yy = y1 + 86
    for label, rate_key, epa_key in cov_rows:
        rank = ranks.get(rate_key) or {}
        epa = number(response.get(epa_key))
        draw.text((x1 + 24, yy), label, font=FONTS["small_bold"], fill=TEXT)
        draw.text((x1 + 260, yy), _fmt_rate(coverage.get(rate_key)), font=FONTS["small_bold"], fill=TEXT, anchor="ra")
        draw.text((x1 + 332, yy), f"#{rank.get('place', '—')}", font=FONTS["small_bold"], fill=_rank_tone(rank.get("place"), rank.get("of")), anchor="ra")
        draw.text((x1 + 430, yy), _fmt_rate(epa, signed=True), font=FONTS["small_bold"], fill=GREEN if epa is not None and epa > 0 else (RED if epa is not None and epa < 0 else MUTED), anchor="ra")
        yy += 38
    pressure = defense.get("pressure") or {}
    pranks = ((((defense_root.get("league_frequency_ranks") or {}).get("defense") or {}).get("pressure")) or {})
    draw.text((x1 + 500, y1 + 58), "PRESSURE MENU", font=MICRO_BOLD, fill=MUTED)
    draw.text((x2 - 150, y1 + 58), "FREQ / RK", font=MICRO_BOLD, fill=MUTED, anchor="ra")
    draw.text((x2 - 24, y1 + 58), "OFF EPA", font=MICRO_BOLD, fill=MUTED, anchor="ra")
    yy = y1 + 92
    for label, key, epa_key in (
        ("BLITZ", "blitz_rate", "pass_epa_blitz"),
        ("PRESSURE", "pressure_rate", "pass_epa_pressure"),
        ("STACKED BOX", "stacked_box_rate", "rush_epa_stacked_box"),
    ):
        rank = pranks.get(key) or {}
        epa = number(response.get(epa_key))
        draw.text((x1 + 500, yy), label, font=FONTS["small_bold"], fill=TEXT)
        draw.text((x2 - 150, yy), f"{_fmt_rate(pressure.get(key))} / #{rank.get('place', '—')}", font=FONTS["small_bold"], fill=_rank_tone(rank.get("place"), rank.get("of")), anchor="ra")
        draw.text((x2 - 24, yy), _fmt_rate(epa, signed=True), font=FONTS["small_bold"], fill=GREEN if epa is not None and epa > 0 else (RED if epa is not None and epa < 0 else MUTED), anchor="ra")
        yy += 66
    target = offense.get("target_share") or {}
    draw.text((x1 + 500, y1 + 294), "OFFENSIVE TARGET MAP", font=MICRO_BOLD, fill=MUTED)
    yy = y1 + 330
    for label, key in (("WR", "target_share_wr_all"), ("TE", "target_share_te_all"), ("RB", "target_share_rb_all")):
        value = number(target.get(key))
        draw.text((x1 + 500, yy), label, font=FONTS["small_bold"], fill=TEXT)
        if value is not None:
            draw.rounded_rectangle((x1 + 552, yy + 4, x1 + 552 + int(265 * value), yy + 19), radius=7, fill=_accent(game.get(off_side)))
        draw.text((x2 - 24, yy), _fmt_rate(value), font=FONTS["small_bold"], fill=TEXT, anchor="ra")
        yy += 40


def _coverage_pressure(bundle: dict, game: dict, out_dir: Path) -> Path:
    image, draw = _base(game, "COVERAGE + PRESSURE", 4, "Every major shell, pressure rate and offensive response on one producer board")
    _coverage_panel(draw, game, "away", (60, 250, 1020, 695))
    _coverage_panel(draw, game, "home", (60, 725, 1020, 1170))
    draw.text((60, 1200), "Rank colors reflect defensive frequency rank; EPA color reflects the offense’s observed response.", font=FONTS["small"], fill=MUTED)
    _footer(draw, bundle, "Published 2025–26 scheme evidence")
    return _save(image, out_dir, f"nfl-{game.get('away')}-{game.get('home')}-booth-04-coverage-pressure.png")


def _status_index(game: dict, side: str) -> dict[str, dict]:
    return {str(row.get("name") or "").casefold(): row for row in game.get(f"{side}_availability_list") or []}


def _personnel_column(draw: ImageDraw.ImageDraw, game: dict, side: str, box: tuple[int, int, int, int]) -> None:
    team = str(game.get(side) or "—")
    x1, y1, x2, _ = box
    _panel(draw, box, accent=_accent(team))
    draw.text((x1 + 24, y1 + 18), f"{team} PERSONNEL", font=FONTS["panel_title"], fill=_accent(team))
    status = _status_index(game, side)
    lineups = game.get(f"{side}_lineups") or {}
    col_w = 203
    for col, unit in enumerate(("offense", "defense")):
        data = lineups.get(unit) or {}
        xx = x1 + 24 + col * (col_w + 6)
        draw.text((xx, y1 + 62), unit.upper(), font=FONTS["small_bold"], fill=PURPLE)
        draw.text((xx, y1 + 88), truncate(data.get("package") or "Package unavailable", 18), font=MICRO, fill=MUTED)
        yy = y1 + 122
        for player in (data.get("players") or [])[:11]:
            row = status.get(str(player.get("name") or "").casefold()) or {}
            designation = str(row.get("status") or "Active")
            tone = GREEN if designation.casefold() == "active" else (RED if "out" in designation.casefold() or "reserve" in designation.casefold() else GOLD)
            draw.text((xx, yy), str(player.get("position") or "—"), font=MICRO_BOLD, fill=MUTED)
            draw.text((xx + 36, yy), truncate(player.get("name") or "Unknown", 16), font=MICRO_BOLD, fill=TEXT)
            draw.ellipse((xx + col_w - 12, yy + 3, xx + col_w - 2, yy + 13), fill=tone)
            yy += 29
    draw.line((x1 + 24, y1 + 455, x2 - 24, y1 + 455), fill=BORDER, width=2)
    draw.text((x1 + 24, y1 + 480), "AVAILABILITY ALERTS", font=FONTS["small_bold"], fill=PURPLE)
    yy = y1 + 520
    alerts = game.get(f"{side}_availability_list") or []
    if not alerts:
        draw.text((x1 + 24, yy), "No published designations", font=FONTS["small"], fill=GREEN)
    for row in alerts[:7]:
        designation = str(row.get("status") or "Active")
        tone = RED if "out" in designation.casefold() or "reserve" in designation.casefold() else GOLD
        detail = f" · {row.get('detail')}" if row.get("detail") else ""
        draw.text((x1 + 24, yy), truncate(f"{row.get('position') or '—'} {row.get('name') or 'Unknown'}", 25), font=FONTS["small_bold"], fill=TEXT)
        draw.text((x2 - 24, yy), truncate(f"{designation}{detail}", 18), font=MICRO_BOLD, fill=tone, anchor="ra")
        yy += 38
    draw.text((x1 + 24, y1 + 814), "Green dot = no attached injury designation.", font=MICRO, fill=MUTED)


def _personnel_page(bundle: dict, game: dict, out_dir: Path) -> Path:
    image, draw = _base(game, "PERSONNEL + AVAILABILITY", 5, "Two-deep producer view with starter status attached by player name")
    _personnel_column(draw, game, "away", (60, 250, 520, 1100))
    _personnel_column(draw, game, "home", (560, 250, 1020, 1100))
    draw.rounded_rectangle((60, 1130, 1020, 1240), radius=18, fill=PANEL_ALT, outline=BORDER, width=1)
    draw.text((82, 1150), "FINAL INACTIVES OVERRIDE THIS BOARD", font=FONTS["small_bold"], fill=GOLD)
    draw.text((82, 1184), "Depth-chart source and injury-report timing differ; recheck before the pregame open.", font=FONTS["small"], fill=TEXT)
    _footer(draw, bundle, "Depth chart + official availability contract")
    return _save(image, out_dir, f"nfl-{game.get('away')}-{game.get('home')}-booth-05-personnel.png")


def _form_row(draw: ImageDraw.ImageDraw, game: dict, key: str, label: str, y: int) -> None:
    away = _team_form_metric(game, "away", key)
    home = _team_form_metric(game, "home", key)
    at = _rank_tone(away.get("rank"), away.get("of"))
    ht = _rank_tone(home.get("rank"), home.get("of"))
    draw.text((82, y), f"#{away.get('rank', '—')}", font=FONTS["small_bold"], fill=at)
    draw.text((165, y), _fmt_form_value(away), font=FONTS["small_bold"], fill=TEXT)
    draw.rounded_rectangle((275, y + 4, 455, y + 18), radius=7, fill=BORDER)
    try:
        fill = int(180 * (1 - ((int(away.get("rank")) - 1) / max(1, int(away.get("of")) - 1))))
    except (TypeError, ValueError):
        fill = 0
    if fill:
        draw.rounded_rectangle((455 - fill, y + 4, 455, y + 18), radius=7, fill=at)
    draw.text((540, y + 2), label, font=MICRO_BOLD, fill=MUTED, anchor="ma")
    draw.rounded_rectangle((625, y + 4, 805, y + 18), radius=7, fill=BORDER)
    try:
        fill = int(180 * (1 - ((int(home.get("rank")) - 1) / max(1, int(home.get("of")) - 1))))
    except (TypeError, ValueError):
        fill = 0
    if fill:
        draw.rounded_rectangle((625, y + 4, 625 + fill, y + 18), radius=7, fill=ht)
    draw.text((915, y), _fmt_form_value(home), font=FONTS["small_bold"], fill=TEXT, anchor="ra")
    draw.text((998, y), f"#{home.get('rank', '—')}", font=FONTS["small_bold"], fill=ht, anchor="ra")


def _team_form(bundle: dict, game: dict, out_dir: Path) -> Path:
    image, draw = _base(game, "TEAM FORM", 6, "Actual values and league ranks on one mirrored scale")
    draw.rounded_rectangle((60, 250, 1020, 1125), radius=22, fill=PANEL, outline=BORDER, width=2)
    draw.text((82, 277), str(game.get("away_name") or game.get("away")), font=FONTS["panel_title"], fill=_accent(game.get("away")))
    draw.text((998, 277), str(game.get("home_name") or game.get("home")), font=FONTS["panel_title"], fill=_accent(game.get("home")), anchor="ra")
    draw.text((82, 326), "RANK", font=MICRO_BOLD, fill=MUTED)
    draw.text((165, 326), "VALUE", font=MICRO_BOLD, fill=MUTED)
    draw.text((540, 326), "METRIC", font=MICRO_BOLD, fill=MUTED, anchor="ma")
    draw.text((915, 326), "VALUE", font=MICRO_BOLD, fill=MUTED, anchor="ra")
    draw.text((998, 326), "RANK", font=MICRO_BOLD, fill=MUTED, anchor="ra")
    rows = (
        ("off_epa", "OFF EPA / PLAY"),
        ("off_first_down", "OFF 1D RATE"),
        ("off_explosive", "OFF EXPLOSIVE"),
        ("off_sack", "SACK RATE TAKEN"),
        ("off_turnover", "GIVEAWAY RATE"),
        ("def_epa", "EPA ALLOWED / PLAY"),
        ("def_first_down", "DEF 1D ALLOWED"),
        ("def_explosive", "DEF EXPLOSIVE"),
        ("def_sack", "SACK RATE MADE"),
        ("def_turnover", "TAKEAWAY RATE"),
    )
    y = 375
    for key, label in rows:
        _form_row(draw, game, key, label, y)
        draw.line((82, y + 42, 998, y + 42), fill="#202430", width=1)
        y += 70
    draw.text((82, 1088), "Ranks already honor whether high or low is better for the metric.", font=MICRO, fill=MUTED)
    draw.rounded_rectangle((60, 1155, 1020, 1240), radius=18, fill="#151221", outline=PURPLE, width=2)
    draw.text((82, 1176), "DIRECTOR'S READ", font=FONTS["small_bold"], fill=PURPLE)
    draw.text((255, 1176), "Use rank to frame relative quality; use the value to explain the football difference.", font=FONTS["small"], fill=TEXT)
    _footer(draw, bundle, "Published team-form pool")
    return _save(image, out_dir, f"nfl-{game.get('away')}-{game.get('home')}-booth-06-team-form.png")


def render_broadcast_booth(
    bundle: dict,
    out_dir: Path,
    game_spec: str,
    *,
    broadcast_notes: dict,
) -> list[Path]:
    game = find_game(bundle, "nfl", game_spec)
    return [
        _matchup_desk(bundle, game, broadcast_notes, out_dir),
        _qb_duel(bundle, game, broadcast_notes, out_dir),
        _formation_lab(bundle, game, out_dir),
        _coverage_pressure(bundle, game, out_dir),
        _personnel_page(bundle, game, out_dir),
        _team_form(bundle, game, out_dir),
    ]


# Pillow keeps ImageColor separate from ImageDraw; import late to make the rendering helpers compact.
from PIL import ImageColor  # noqa: E402  (intentional late import)
