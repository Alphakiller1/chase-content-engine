@echo off
setlocal
cd /d "%~dp0"
title Chase Analytics - Tomorrow's Four Games
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-BroadcastBooth.ps1" -Games "CIN@HOU,JAX@DEN,WSH@DAL,PIT@NE"
echo.
if errorlevel 1 (
  echo The booth did not finish. Send broadcast-booth-launch.log for diagnosis.
) else (
  echo All four game packages are ready in dist\broadcast-booth.
)
pause

