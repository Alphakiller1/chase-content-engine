@echo off
setlocal
cd /d "%~dp0"
title Chase Analytics Broadcasting Booth Installer
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-BroadcastBooth.ps1"
echo.
if errorlevel 1 (
  echo Installation did not finish. Leave this window open and copy the error message.
) else (
  echo Installation finished successfully.
)
pause

