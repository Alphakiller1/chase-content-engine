$script:ChaseBoothRoot = Split-Path -Parent $PSScriptRoot
$script:ChaseBoothNotes = Join-Path $PSScriptRoot '2026-week-02.json'
$script:ChaseBoothOutput = Join-Path $script:ChaseBoothRoot 'dist\broadcast-booth'
$script:ChaseBoothPython = Join-Path $script:ChaseBoothRoot '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $script:ChaseBoothPython)) {
    $script:ChaseBoothPython = 'python'
}

function Get-ChaseBoothGames {
    [CmdletBinding()]
    param(
        [int]$Week = 0
    )

    Push-Location $script:ChaseBoothRoot
    try {
        $Arguments = @(
            '-m', 'chase_content', 'booth',
            '--site-base', 'https://chase-analytics.com',
            '--broadcast-notes', $script:ChaseBoothNotes,
            '--out', $script:ChaseBoothOutput,
            '--list'
        )
        if ($Week -gt 0) {
            $Arguments += @('--week', $Week)
        }
        & $script:ChaseBoothPython @Arguments
    }
    finally {
        Pop-Location
    }
}

function Start-ChaseBooth {
    [CmdletBinding()]
    param(
        [string]$Games = '',
        [int]$Week = 0,
        [string]$Output = $script:ChaseBoothOutput
    )

    Push-Location $script:ChaseBoothRoot
    try {
        $Arguments = @(
            '-m', 'chase_content', 'booth',
            '--site-base', 'https://chase-analytics.com',
            '--broadcast-notes', $script:ChaseBoothNotes,
            '--out', $Output
        )
        if ($Games) {
            $Arguments += @('--games', $Games)
        }
        if ($Week -gt 0) {
            $Arguments += @('--week', $Week)
        }
        & $script:ChaseBoothPython @Arguments
    }
    finally {
        Pop-Location
    }
}

function Open-ChaseBoothRunbook {
    [CmdletBinding()]
    param(
        [string]$Output = $script:ChaseBoothOutput
    )

    $Runbook = Join-Path $Output 'broadcast-booth-producer-runbook.md'
    if (-not (Test-Path -LiteralPath $Runbook)) {
        throw "Runbook not found. Run Start-ChaseBooth first: $Runbook"
    }
    Invoke-Item -LiteralPath $Runbook
}

Write-Host 'Broadcasting Booth functions loaded:' -ForegroundColor Magenta
Write-Host '  Get-ChaseBoothGames'
Write-Host '  Start-ChaseBooth'
Write-Host '  Open-ChaseBoothRunbook'
