# Broadcasting Booth package

The `nfl-broadcast-booth` report turns one NFL matchup into a six-image, 1080×1350
producer package:

1. Matchup Desk
2. QB Duel
3. Formation Lab
4. Coverage + Pressure
5. Personnel + Availability
6. Team Form

Live team, lineup, injury, formation, coverage, pressure, target-share, travel and form
evidence comes from the Chase Analytics public NFL contract. The optional notes file adds
clearly sourced, editorial context such as the prior week's quarterback box score. These
inputs are deliberately labeled with different evidence windows in the output.

```bash
chase-content site-daily \
  --site-base https://chase-analytics.com \
  --report nfl-broadcast-booth \
  --game CIN@HOU \
  --broadcast-notes broadcast_booth/2026-week-02.json \
  --out dist/2026-week-02/CIN-HOU
```

Repeat the command for `JAX@DEN`, `WSH@DAL`, and `PIT@NE`.

## Game picker

The `booth` command lists the active NFL week and accepts menu numbers, `AWAY@HOME`
keys, or `all`. Omit `--games` to use the interactive picker.

```powershell
python -m chase_content booth --site-base https://chase-analytics.com `
  --broadcast-notes broadcast_booth/2026-week-02.json `
  --out dist/broadcast-booth
```

Dot-source `terminal-functions.ps1` to install short PowerShell functions in the current
terminal session.
