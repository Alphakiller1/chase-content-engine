@echo off
setlocal
cd /d "%~dp0"
title Chase Analytics - Available NFL Games
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-BroadcastBooth.ps1" -ListOnly
echo.
pause

