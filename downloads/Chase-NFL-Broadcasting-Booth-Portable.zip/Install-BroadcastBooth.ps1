[CmdletBinding()]
param(
    [string]$InstallRoot = (Join-Path $env:LOCALAPPDATA 'ChaseNFLBooth'),
    [switch]$SkipShortcuts,
    [switch]$SkipProfiles
)

$ErrorActionPreference = 'Stop'
$SourceRoot = [System.IO.Path]::GetFullPath($PSScriptRoot)
$InstallRoot = [System.IO.Path]::GetFullPath($InstallRoot)

function Write-Step([string]$Message) {
    Write-Host "`n$Message" -ForegroundColor Cyan
}

try {
    Write-Host 'CHASE ANALYTICS BROADCASTING BOOTH INSTALLER' -ForegroundColor Magenta
    Write-Host "Source:  $SourceRoot"
    Write-Host "Install: $InstallRoot"

    if ($SourceRoot.TrimEnd('\') -ne $InstallRoot.TrimEnd('\')) {
        Write-Step 'Copying the booth to its permanent local folder...'
        New-Item -ItemType Directory -Path $InstallRoot -Force | Out-Null
        $CopyArguments = @(
            $SourceRoot,
            $InstallRoot,
            '/E',
            '/XD', '.git', '.venv', 'dist', '__pycache__', '.pytest_cache',
            '/XF', '*.pyc', 'broadcast-booth-launch.log',
            '/NFL', '/NDL', '/NJH', '/NJS', '/NP'
        )
        & robocopy.exe @CopyArguments
        if ($LASTEXITCODE -gt 7) {
            throw "The installer could not copy the booth. Robocopy exit code: $LASTEXITCODE"
        }
    }

    $VenvPython = Join-Path $InstallRoot '.venv\Scripts\python.exe'
    if (-not (Test-Path -LiteralPath $VenvPython)) {
        Write-Step 'Creating the private Python environment...'
        $PyLauncher = Get-Command py.exe -ErrorAction SilentlyContinue
        if ($PyLauncher) {
            & $PyLauncher.Source -3 -m venv (Join-Path $InstallRoot '.venv')
        }
        else {
            $Python = Get-Command python.exe -ErrorAction SilentlyContinue
            if (-not $Python) {
                throw 'Python 3.11 or newer was not found. Install Python from python.org, then run INSTALL-BOOTH.cmd again.'
            }
            & $Python.Source -m venv (Join-Path $InstallRoot '.venv')
        }
        if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $VenvPython)) {
            throw 'The private Python environment could not be created.'
        }
    }

    Write-Step 'Installing the graphics and time-zone packages...'
    & $VenvPython -m pip install --disable-pip-version-check -e $InstallRoot
    if ($LASTEXITCODE -ne 0) {
        throw 'The Python package installation failed.'
    }
    New-Item -ItemType File -Path (Join-Path $InstallRoot '.venv\broadcast-booth-ready-v2') -Force | Out-Null

    Write-Step 'Installing terminal commands...'
    $BinPath = Join-Path $InstallRoot 'bin'
    New-Item -ItemType Directory -Path $BinPath -Force | Out-Null
    $PowerShellScript = Join-Path $InstallRoot 'Start-BroadcastBooth.ps1'
    $BoothWrapper = "@echo off`r`npowershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File `"$PowerShellScript`" %*`r`nexit /b %errorlevel%`r`n"
    $ListWrapper = "@echo off`r`npowershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File `"$PowerShellScript`" -ListOnly`r`nexit /b %errorlevel%`r`n"
    $FourWrapper = "@echo off`r`npowershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File `"$PowerShellScript`" -Games `"CIN@HOU,JAX@DEN,WSH@DAL,PIT@NE`"`r`nexit /b %errorlevel%`r`n"
    Set-Content -LiteralPath (Join-Path $BinPath 'booth.cmd') -Value $BoothWrapper -Encoding Ascii
    Set-Content -LiteralPath (Join-Path $BinPath 'booth-list.cmd') -Value $ListWrapper -Encoding Ascii
    Set-Content -LiteralPath (Join-Path $BinPath 'booth-four.cmd') -Value $FourWrapper -Encoding Ascii

    $UserPath = [Environment]::GetEnvironmentVariable('Path', 'User')
    $UserPathItems = @($UserPath -split ';' | Where-Object { $_ })
    if ($UserPathItems -notcontains $BinPath) {
        [Environment]::SetEnvironmentVariable('Path', (($UserPathItems + $BinPath) -join ';'), 'User')
    }
    if (($env:Path -split ';') -notcontains $BinPath) {
        $env:Path = "$BinPath;$env:Path"
    }

    if (-not $SkipProfiles) {
        Write-Step 'Installing PowerShell functions...'
        try {
            Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned -Force -ErrorAction Stop
        }
        catch {
            Write-Warning "The execution policy could not be changed: $($_.Exception.Message)"
        }
        $EscapedScript = $PowerShellScript.Replace("'", "''")
        $ProfileBlock = @"
# >>> Chase NFL Booth >>>
function booth {
    & powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File '$EscapedScript' @args
}
function booth-list {
    & powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File '$EscapedScript' -ListOnly
}
function booth-four {
    & powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File '$EscapedScript' -Games 'CIN@HOU,JAX@DEN,WSH@DAL,PIT@NE'
}
# <<< Chase NFL Booth <<<
"@
        $Documents = [Environment]::GetFolderPath('MyDocuments')
        foreach ($ProfilePath in @(
            (Join-Path $Documents 'WindowsPowerShell\profile.ps1'),
            (Join-Path $Documents 'PowerShell\profile.ps1')
        )) {
            New-Item -ItemType Directory -Path (Split-Path -Parent $ProfilePath) -Force | Out-Null
            $Existing = if (Test-Path -LiteralPath $ProfilePath) { Get-Content -LiteralPath $ProfilePath -Raw } else { '' }
            $Pattern = '(?s)# >>> Chase NFL Booth >>>.*?# <<< Chase NFL Booth <<<\s*'
            $Updated = [regex]::Replace($Existing, $Pattern, '').TrimEnd()
            if ($Updated) { $Updated += "`r`n`r`n" }
            $Updated += $ProfileBlock.Trim() + "`r`n"
            Set-Content -LiteralPath $ProfilePath -Value $Updated -Encoding UTF8
        }
    }

    if (-not $SkipShortcuts) {
        Write-Step 'Creating desktop shortcuts...'
        $Desktop = [Environment]::GetFolderPath('Desktop')
        $Shell = New-Object -ComObject WScript.Shell
        $PowerShellExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
        $OutputPath = Join-Path $InstallRoot 'dist\broadcast-booth'
        New-Item -ItemType Directory -Path $OutputPath -Force | Out-Null

        $Picker = $Shell.CreateShortcut((Join-Path $Desktop 'Broadcasting Booth.lnk'))
        $Picker.TargetPath = $PowerShellExe
        $Picker.Arguments = "-NoLogo -NoProfile -ExecutionPolicy Bypass -File `"$PowerShellScript`""
        $Picker.WorkingDirectory = $InstallRoot
        $Picker.Description = 'Open the NFL Broadcasting Booth game picker'
        $Picker.Save()

        $Four = $Shell.CreateShortcut((Join-Path $Desktop "Tomorrow's Four NFL Games.lnk"))
        $Four.TargetPath = $PowerShellExe
        $Four.Arguments = "-NoLogo -NoProfile -ExecutionPolicy Bypass -File `"$PowerShellScript`" -Games `"CIN@HOU,JAX@DEN,WSH@DAL,PIT@NE`""
        $Four.WorkingDirectory = $InstallRoot
        $Four.Description = 'Generate the four prepared NFL matchup packages'
        $Four.Save()

        $Outputs = $Shell.CreateShortcut((Join-Path $Desktop 'Broadcasting Booth Outputs.lnk'))
        $Outputs.TargetPath = (Join-Path $env:SystemRoot 'explorer.exe')
        $Outputs.Arguments = "`"$OutputPath`""
        $Outputs.WorkingDirectory = $InstallRoot
        $Outputs.Description = 'Open the generated Broadcasting Booth outputs'
        $Outputs.Save()
    }

    Write-Step 'Verifying the installed command...'
    & (Join-Path $BinPath 'booth-list.cmd')
    if ($LASTEXITCODE -ne 0) {
        throw 'The installed booth-list command failed its verification run.'
    }

    Write-Host "`nINSTALLATION COMPLETE" -ForegroundColor Green
    Write-Host 'Open a new terminal and type: booth'
    Write-Host 'Or double-click Broadcasting Booth on the desktop.'
}
catch {
    Write-Host "`nINSTALLATION FAILED: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

