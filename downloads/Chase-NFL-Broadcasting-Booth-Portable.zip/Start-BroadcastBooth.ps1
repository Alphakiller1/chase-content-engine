[CmdletBinding()]
param(
    [string]$Games = '',
    [switch]$ListOnly
)

$ErrorActionPreference = 'Stop'
$Root = $PSScriptRoot
$VenvPython = Join-Path $Root '.venv\Scripts\python.exe'
$ReadyMarker = Join-Path $Root '.venv\broadcast-booth-ready-v2'
$LogPath = Join-Path $Root 'broadcast-booth-launch.log'
$OutputPath = Join-Path $Root 'dist\broadcast-booth'
$NotesPath = Join-Path $Root 'broadcast_booth\2026-week-02.json'

Set-Location -LiteralPath $Root

try {
    try { Start-Transcript -LiteralPath $LogPath -Append | Out-Null } catch {}

    Write-Host ''
    Write-Host 'CHASE ANALYTICS BROADCASTING BOOTH' -ForegroundColor Magenta
    Write-Host "Engine folder: $Root"

    if (-not (Test-Path -LiteralPath $VenvPython)) {
        Write-Host 'First launch: creating the private Python environment...'
        $PyLauncher = Get-Command py.exe -ErrorAction SilentlyContinue
        if ($PyLauncher) {
            & $PyLauncher.Source -3 -m venv '.venv'
        }
        else {
            $Python = Get-Command python.exe -ErrorAction SilentlyContinue
            if (-not $Python) {
                throw 'Python 3.11 or newer was not found. Install Python, then double-click START-BOOTH.cmd again.'
            }
            & $Python.Source -m venv '.venv'
        }
        if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $VenvPython)) {
            throw 'The private Python environment could not be created.'
        }
    }

    if (-not (Test-Path -LiteralPath $ReadyMarker)) {
        Write-Host 'Installing the booth locally. This happens only on the first launch...'
        & $VenvPython -m pip install --disable-pip-version-check -e .
        if ($LASTEXITCODE -ne 0) {
            throw 'The booth installation failed. See broadcast-booth-launch.log.'
        }
        New-Item -ItemType File -Path $ReadyMarker -Force | Out-Null
    }

    $Arguments = @(
        '-m', 'chase_content', 'booth',
        '--site-base', 'https://chase-analytics.com',
        '--broadcast-notes', $NotesPath,
        '--out', $OutputPath
    )
    if ($Games) { $Arguments += @('--games', $Games) }
    if ($ListOnly) { $Arguments += '--list' }

    $env:PYTHONUTF8 = '1'
    & $VenvPython @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw 'The booth command failed. See broadcast-booth-launch.log.'
    }

    if (-not $ListOnly) {
        Write-Host ''
        Write-Host "READY. Your graphics and export documents are in: $OutputPath" -ForegroundColor Green
    }
}
catch {
    Write-Host ''
    Write-Host "BOOTH ERROR: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Diagnostic log: $LogPath" -ForegroundColor Yellow
    exit 1
}
finally {
    try { Stop-Transcript | Out-Null } catch {}
}

