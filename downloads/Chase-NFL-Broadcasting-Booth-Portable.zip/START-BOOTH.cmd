@echo off
setlocal
cd /d "%~dp0"
title Chase Analytics Broadcasting Booth
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-BroadcastBooth.ps1"
echo.
if errorlevel 1 (
  echo The booth did not start. Send broadcast-booth-launch.log for diagnosis.
) else (
  echo Booth session complete.
)
pause

